//@input SceneObject hornetObject
//@input vec3 resetPosition

var transform = script.hornetObject.getTransform();
transform.setWorldPosition(script.resetPosition);
