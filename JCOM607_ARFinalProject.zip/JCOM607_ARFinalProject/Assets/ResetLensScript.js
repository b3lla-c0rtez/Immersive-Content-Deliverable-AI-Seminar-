
// -----JS CODE-----

// This script resets the scene and positions when "Play Again" is pressed

// @input Component.ScriptComponent sceneManager
// @input SceneObject hornet
// @input vec3 hornetStartPosition
// @input SceneObject startUI
// @input SceneObject endUI

function resetLens() {
    // Reset the scene
    if (script.sceneManager && script.sceneManager.api.reset) {
        script.sceneManager.api.reset();
    }

    // Reset Hornet's position
    if (script.hornet) {
        script.hornet.getTransform().setWorldPosition(script.hornetStartPosition);
    }

    // Toggle UI screens
    if (script.startUI) {
        script.startUI.enabled = true;
    }
    if (script.endUI) {
        script.endUI.enabled = false;
    }
}

// Register the reset function with a custom trigger
global.behaviorSystem.addCustomTrigger("resetLens", resetLens);
