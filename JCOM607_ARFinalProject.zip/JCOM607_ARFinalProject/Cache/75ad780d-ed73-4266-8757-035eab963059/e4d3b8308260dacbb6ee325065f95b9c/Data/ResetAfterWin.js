var resetDelay = 5.0; // seconds

var delayedEvent = script.createEvent("DelayedCallbackEvent");
delayedEvent.bind(function() {
    global.scene.reloadScene();
});
delayedEvent.reset(resetDelay);
